import { useEffect, useRef, useState } from "react";
import heroBg from "assets/back.webp";
import heroBuilding from "assets/house.webp";
import heroCloud from "assets/cloud.webp";
import heroCloudScroll from "assets/smoke.webp";

export const HeroSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [viewportH, setViewportH] = useState(0);
  const [viewportW, setViewportW] = useState(0);

  useEffect(() => {
    setViewportH(window.innerHeight);
    setViewportW(window.innerWidth);
    const onResize = () => {
      setViewportH(window.innerHeight);
      setViewportW(window.innerWidth);
    };
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      try {
        const section = sectionRef.current;
        if (!section) return;
        const sectionHeight = section.offsetHeight || 0;
        const scrolled = (window.scrollY || 0) - (section.offsetTop || 0);
        const scrollRange = sectionHeight - (viewportH || window.innerHeight || 800);
        const progress =
          scrollRange > 0 ? Math.max(0, Math.min(1, scrolled / scrollRange)) : 0;
        setScrollProgress(progress);
      } catch (err) {
        console.error("Scroll error:", err);
      }
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener("scroll", handleScroll);
  }, [viewportH]);

  // Fade the real <Header> element in sync with hero scroll
  useEffect(() => {
    const header = document.querySelector("header") as HTMLElement | null;
    if (!header) return;
    const p1 = Math.min(1, scrollProgress / 0.45);
    const opacity = Math.max(0, 1 - p1 * 4);
    header.style.opacity = String(opacity);
    header.style.pointerEvents = opacity < 0.05 ? "none" : "";
    header.style.transition = "opacity 0.1s linear";
    return () => {
      // Restore when hero unmounts
      header.style.opacity = "";
      header.style.pointerEvents = "";
      header.style.transition = "";
    };
  }, [scrollProgress]);

  const easeOut = (t: number) => 1 - Math.pow(1 - t, 2);

  // Phase 1: 0 → 0.45  (hero content fades, clouds spread, smoke rises)
  // Phase 2: 0.45 → 0.85 (text stroke draws in, then image fills through letters)
  // Phase 3: 0.92 → 1.0 (white cover for section exit)
  const p1 = Math.min(1, scrollProgress / 0.45);
  const p2 = Math.max(0, Math.min(1, (scrollProgress - 0.45) / 0.40));
  const p3 = Math.max(0, Math.min(1, (scrollProgress - 0.92) / 0.08));

  const p1e = easeOut(p1);
  const p2e = easeOut(p2);

  // ── Sub-phases of Phase 2 ──────────────────────────────────────────────
  //  Stage A (p2: 0.00 → 0.55)  PARMAR stroke draws in
  //  Stage B (p2: 0.12 → 0.68)  PROPERTIES stroke draws in (staggered)
  //  Stage C (p2: 0.55 → 1.00)  image fill fades in through letter cutouts
  //  Stage D (p2: 0.60 → 0.90)  strokes + scrim fade out
  const STROKE_LEN = 8000;

  const parmarStrokeP  = easeOut(Math.min(1, p2 / 0.55));
  const propsStrokeP   = easeOut(Math.max(0, Math.min(1, (p2 - 0.12) / 0.56)));
  const strokeOffsetP  = STROKE_LEN * (1 - parmarStrokeP);
  const strokeOffsetPr = STROKE_LEN * (1 - propsStrokeP);

  // Scrim: subtle dark veil that makes white strokes legible, fades when fill is complete
  const scrimOpacity = Math.max(0, Math.min(0.35, p2 * 1.2) - easeOut(Math.max(0, (p2 - 0.58) / 0.32)) * 0.35);

  // Stroke opacity: visible once p2 starts, fades out as image fill takes over
  const strokeOpacity = Math.max(0, Math.min(1, p2 * 6) - easeOut(Math.max(0, (p2 - 0.60) / 0.30)));

  // Image fill: appears once strokes are mostly drawn, completes before p2 ends
  const fillProgress  = easeOut(Math.max(0, Math.min(1, (p2 - 0.52) / 0.48)));

  // Overall text layer scale: zooms in gently as p2 progresses
  const maskScale = 0.82 + p2e * 0.18;

  // Parallax for images inside the text cutouts
  const maskParallaxY = p2e * -6;

  // Sky subtle zoom
  const skyScale = 1 + p1e * 0.08;

  // Building rises up into frame, then subtly grows
  const buildingY = (1 - p1e) * 55 + p2e * -8;
  const buildingScale = 1 + p2e * 0.04;

  // Hero text fades and lifts away early
  const contentOpacity = Math.max(0, 1 - p1 * 2.2);
  const contentY = p1e * -60;

  // Decorative clouds slide apart
  const cloudLeftX = -p1e * 60;
  const cloudLeftOpacity = Math.max(0, 1 - p2 * 2.5);
  const cloudRightX = p1e * 60;
  const cloudRightOpacity = Math.max(0, 1 - p2 * 2.5);

  // Smoke cloud rises and expands
  const scrollCloudY = (1 - p1e) * 35 + p2e * -15;
  const scrollCloudScale = 1 + p1e * 0.15 + p2e * 0.25;
  const scrollCloudOpacity = Math.min(1, p1 * 1.8) * Math.max(0, 1 - p2 * 1.2);

  // Final white cover — only last 8% of scroll
  const whiteOpacity = p3;

  // Dark tint over sky (only phase 1)
  const darkOpacity = 0.18 * (1 - p2e);

  // Bottom gradient fades as mask takes over
  const bottomGradientOpacity = 1 - p2e;

  // Navbar fades out as user scrolls (synced to real <header> via useEffect)
  const navOpacity = Math.max(0, 1 - p1 * 4);

  return (
    <>
      {/* ── Hero Section ── */}
      <section
        ref={sectionRef}
        style={{ height: "400vh" }}
        className="relative w-full"
      >
        <div className="sticky top-0 h-screen w-full overflow-hidden">

          {/* Layer 1: Sky background */}
          <div
            className="absolute inset-0"
            style={{
              transform: `scale(${skyScale})`,
              transformOrigin: "center center",
              willChange: "transform",
            }}
          >
            <img
              src={heroBg}
              alt=""
              aria-hidden="true"
              className="w-full h-full object-cover"
            />
          </div>

          {/* Layer 2: Subtle dark tint (phase 1 only) */}
          <div
            className="absolute inset-0 bg-black pointer-events-none"
            style={{ opacity: darkOpacity }}
          />

          {/* Layer 3: Building — anchored to bottom, natural proportions (rooftop visible) */}
          <div
            className="absolute bottom-0 inset-x-0 pointer-events-none z-10"
            style={{
              transform: `translateY(${buildingY}%) scale(${buildingScale})`,
              transformOrigin: "bottom center",
              willChange: "transform",
            }}
          >
            <img
              src={heroBuilding}
              alt="Luxury real estate building"
              className="w-full h-auto block"
            />
          </div>

          {/* Layer 4a: Left Cloud */}
          <div
            className="absolute pointer-events-none z-20"
            style={{
              bottom: "10%",
              left: "-10%",
              width: "55%",
              opacity: cloudLeftOpacity,
              transform: `translateX(${cloudLeftX}px)`,
              willChange: "transform, opacity",
            }}
          >
            <img src={heroCloud} alt="" aria-hidden="true" className="w-full h-auto" />
          </div>

          {/* Layer 4b: Right Cloud */}
          <div
            className="absolute pointer-events-none z-20"
            style={{
              bottom: "15%",
              right: "-10%",
              width: "55%",
              opacity: cloudRightOpacity,
              transform: `translateX(${cloudRightX}px) scaleX(-1)`,
              willChange: "transform, opacity",
            }}
          >
            <img src={heroCloud} alt="" aria-hidden="true" className="w-full h-auto" />
          </div>

          {/* Layer 5: Bottom gradient (fades during mask phase) */}
          <div
            className="absolute bottom-0 inset-x-0 pointer-events-none z-20"
            style={{
              height: "40%",
              background:
                "linear-gradient(to top, rgba(255,255,255,0.65) 0%, transparent 100%)",
              opacity: bottomGradientOpacity,
            }}
          />

          {/* Layer 6: Smoke cloud */}
          <div
            className="absolute pointer-events-none z-30"
            style={{
              bottom: "-10%",
              left: "-10%",
              width: "120%",
              opacity: scrollCloudOpacity,
              transform: `translateY(${scrollCloudY}%) scale(${scrollCloudScale})`,
              willChange: "transform, opacity",
            }}
          >
            <img
              src={heroCloudScroll}
              alt=""
              aria-hidden="true"
              className="w-full h-auto object-cover"
              style={{ minHeight: "40vh" }}
            />
          </div>

          {/* Layer 7: PARMAR PROPERTIES ─ 3-stage scroll animation
              Stage A: invisible
              Stage B: white strokes draw in (PARMAR first, then PROPERTIES)
              Stage C: sky+building image fills through letter cutouts, strokes fade out
          */}
          <div
            className="absolute inset-0 pointer-events-none z-40"
            style={{
              transform: `scale(${maskScale})`,
              transformOrigin: "center center",
              willChange: "transform",
            }}
          >
            {/* Subtle dark scrim – gives white strokes contrast against bright sky.
                Appears with first scroll, fades once image fill is complete. */}
            <div
              className="absolute inset-0"
              style={{
                background: "rgba(10,8,6,1)",
                opacity: scrimOpacity,
              }}
            />

            <svg
              className="absolute inset-0 w-full h-full"
              xmlns="http://www.w3.org/2000/svg"
              xmlnsXlink="http://www.w3.org/1999/xlink"
              aria-hidden="true"
            >
              <defs>
                <mask id="parmar-mask">
                  <rect width="100%" height="100%" fill="black" />
                  <text
                    x="50%" y="44%"
                    textAnchor="middle" dominantBaseline="middle"
                    fontFamily="'Instrument Sans', Helvetica, Arial, sans-serif"
                    fontWeight="700"
                    style={{ fontSize: "clamp(48px, 12vw, 300px)" }}
                    letterSpacing="-0.04em"
                    fill="white"
                  >PARMAR</text>
                  <text
                    x="50%" y="62%"
                    textAnchor="middle" dominantBaseline="middle"
                    fontFamily="'Instrument Sans', Helvetica, Arial, sans-serif"
                    fontWeight="700"
                    style={{ fontSize: "clamp(28px, 7vw, 150px)" }}
                    letterSpacing="0.12em"
                    fill="white"
                  >PROPERTIES</text>
                </mask>
              </defs>

              {/* ── Stage C: sky + building image through letter cutouts ──
                  fillProgress: 0 until strokes complete, then fades to 1.            */}
              <g mask="url(#parmar-mask)" style={{ opacity: fillProgress }}>
                <image
                  xlinkHref={heroBg}
                  x="0" y={`${maskParallaxY}%`}
                  width="100%" height="110%"
                  preserveAspectRatio="xMidYMid slice"
                />
                <image
                  xlinkHref={heroBuilding}
                  x="0" y={`${maskParallaxY * 0.6}%`}
                  width="100%" height="100%"
                  preserveAspectRatio="xMidYMax slice"
                />
              </g>

              {/* ── Stage B: PARMAR stroke draws in ── */}
              <text
                x="50%" y="44%"
                textAnchor="middle" dominantBaseline="middle"
                fontFamily="'Instrument Sans', Helvetica, Arial, sans-serif"
                fontWeight="700"
                style={{ fontSize: "clamp(48px, 12vw, 300px)" }}
                letterSpacing="-0.04em"
                fill="none"
                stroke="rgba(255,255,255,0.92)"
                strokeWidth="2.5"
                strokeDasharray={`${STROKE_LEN}`}
                strokeDashoffset={`${strokeOffsetP}`}
                strokeLinecap="round"
                strokeLinejoin="round"
                opacity={strokeOpacity}
              >PARMAR</text>

              {/* ── Stage B: PROPERTIES stroke draws in (staggered) ── */}
              <text
                x="50%" y="62%"
                textAnchor="middle" dominantBaseline="middle"
                fontFamily="'Instrument Sans', Helvetica, Arial, sans-serif"
                fontWeight="700"
                style={{ fontSize: "clamp(28px, 7vw, 150px)" }}
                letterSpacing="0.12em"
                fill="none"
                stroke="rgba(255,255,255,0.92)"
                strokeWidth="2"
                strokeDasharray={`${STROKE_LEN}`}
                strokeDashoffset={`${strokeOffsetPr}`}
                strokeLinecap="round"
                strokeLinejoin="round"
                opacity={strokeOpacity}
              >PROPERTIES</text>
            </svg>
          </div>

          {/* Layer 8: Final white cover — section exit only */}
          <div
            className="absolute inset-0 bg-white pointer-events-none z-50"
            style={{ opacity: whiteOpacity }}
          />

          {/* Layer 9: Hero content — sits in upper portion of screen */}
          <div
            className="absolute inset-0 flex flex-col items-center justify-start z-30 text-center px-6"
            style={{
              paddingTop: "18vh",
              opacity: contentOpacity,
              transform: `translateY(${contentY}px)`,
              pointerEvents: contentOpacity < 0.05 ? "none" : "auto",
            }}
          >
            {/* Eyebrow */}
            <p
              className="text-white/70 text-xs font-semibold tracking-[0.25em] uppercase mb-4"
              style={{ fontFamily: "'Instrument Sans', sans-serif" }}
            >
              Expert Real Estate Agents
            </p>

            {/* Headline */}
            <h1
              className="text-white font-bold leading-[1.05] mb-5"
              style={{
                fontFamily: "'Instrument Sans', sans-serif",
                fontSize: "clamp(42px, 7.5vw, 110px)",
                letterSpacing: "-0.03em",
                textShadow: "0 2px 24px rgba(0,0,0,0.18)",
              }}
            >
              Find What Moves You
            </h1>

            {/* Subtitle */}
            <p
              className="text-white/85 mb-10 max-w-xl leading-relaxed"
              style={{
                fontFamily: "'Instrument Sans', sans-serif",
                fontSize: "clamp(15px, 1.4vw, 19px)",
              }}
            >
              <strong className="font-semibold text-white">
                Expert agents. Real guidance.
              </strong>{" "}
              A clear path to find what's next.
            </p>

            {/* CTA */}
            <a
              href="#"
              className="inline-flex items-center gap-2 bg-gray-900 text-white font-semibold rounded-full px-7 py-3.5 hover:bg-gray-800 transition-colors"
              style={{
                fontFamily: "'Instrument Sans', sans-serif",
                fontSize: "clamp(14px, 1.1vw, 16px)",
              }}
            >
              Find Properties
              <span>→</span>
            </a>
          </div>

          {/* Layer 10: Scroll hint */}
          <div
            className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 pointer-events-none select-none z-30"
            style={{ opacity: Math.max(0, 1 - p1 * 3.5) }}
          >
            <span
              className="text-[10px] tracking-[0.3em] uppercase text-white/60"
              style={{ fontFamily: "'Instrument Sans', sans-serif" }}
            >
              Scroll
            </span>
            <div className="w-px h-8 bg-gradient-to-b from-white/50 to-transparent animate-pulse" />
          </div>

        </div>
      </section>
    </>
  );
};